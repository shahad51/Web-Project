let SignUpBtn = document.getElementById("SignUpBtn");
  let LogInBtn = document.getElementById("LogInBtn");
  let FirstNameField = document.getElementById("FirstNameField");
  let LastNameField = document.getElementById("LastNameField");
  let title = document.getElementById("title");

  LogInBtn.onclick=function(){
    FirstNameField.style.maxHeight="0";
    LastNameField.style.maxHeight="0";
    title.innerHTML="Log In";
    SignUpBtn.classList.add("disable");
    LogInBtn.classList.remove("disable");
  }

  SignUpBtn.onclick=function(){
    FirstNameField.style.maxHeight="60px";
    LastNameField.style.maxHeight="60px";
    title.innerHTML="Sign Up";
    SignUpBtn.classList.remove("disable");
    LogInBtn.classList.add("disable");
  }
