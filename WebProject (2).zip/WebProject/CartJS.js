document.querySelectorAll('.delete').forEach(button => {
    button.addEventListener('click', function() {
      this.closest('.item').querySelector('input[type="number"]').value = 0;
    });
  });
  
  document.querySelectorAll('.quantity button').forEach(button => {
    button.addEventListener('click', function() {
      const input = this.parentElement.querySelector('input');
      const value = parseInt(input.value);
      if (this.textContent === '-') {
        if (value > 0) input.value = value - 1;
      } else {
        input.value = value + 1;
      }
    });
  });
  

const deleteButtons = document.querySelectorAll('.delete');

deleteButtons.forEach((button, index) => {
  button.addEventListener('click', () => {
    const item = button.closest('.item');

    item.remove();

    updateTotal();
  });
});

function updateTotal() {
  const items = document.querySelectorAll('.item');
  let total = 0;

  items.forEach((item) => {
    const price = parseFloat(item.querySelector('.info span').textContent.replace('SR ', ''));
    const quantity = parseInt(item.querySelector('input[type="number"]').value);
    total += price * quantity;
  });

  document.querySelector('.footer button').textContent = `Pay SR ${total.toFixed(2)}`;
}

updateTotal();