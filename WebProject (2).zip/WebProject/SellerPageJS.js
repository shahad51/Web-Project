const form = document.getElementById('ad-form');

form.addEventListener('submit', (event) => {
    event.preventDefault(); 
    const formData = new FormData(form);


    window.location.href = 'Shop.html';
});

const photoInput = document.querySelector('.photo-input');

const photoSlot = document.querySelector('.photo-slot');

photoInput.addEventListener('change', function() {
    const file = this.files[0];

    if (file) {
        const img = document.createElement('img');

        img.src = URL.createObjectURL(file);

        img.width = 150;
        img.height = 150;

        photoSlot.innerHTML = '';
        photoSlot.appendChild(img);
    }
});


