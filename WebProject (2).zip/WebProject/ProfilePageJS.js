// Get the edit button and profile form
const editButton = document.querySelector('.edit-button');
const profileForm = document.querySelector('.profile-form');

// Add an event listener to the edit button
editButton.addEventListener('click', () => {
  profileForm.classList.toggle('editable');
});

// Get all the input fields and dropdown menus
const usernameInput = profileForm.querySelector('input[name="username"]');
const passwordInput = profileForm.querySelector('input[name="password"]');
const phoneInput = profileForm.querySelector('input[name="phone"]');
const emailInput = profileForm.querySelector('input[name="email"]');
const languageSelect = profileForm.querySelector('select[name="language"]');
const regionSelect = profileForm.querySelector('select[name="Region"]');

// Add event listeners to the input fields and dropdown menus
usernameInput.addEventListener('input', handleInputChange);
passwordInput.addEventListener('input', handleInputChange);
phoneInput.addEventListener('input', handleInputChange);
emailInput.addEventListener('input', handleInputChange);
languageSelect.addEventListener('change', handleInputChange);
regionSelect.addEventListener('change', handleInputChange);

// Function to handle input changes
function handleInputChange() {
  // Enable the save button if any of the fields have been modified
  const saveButton = profileForm.querySelector('button[type="Save"]');
  saveButton.disabled = false;
}